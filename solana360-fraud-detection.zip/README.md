# Solana 360 - Smart Contract Fraud Detection

Blockchain fraud detection system on GCP using clustering + logistic regression.
